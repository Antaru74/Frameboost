//! fbd - FrameBoost daemon (root, native).
//! Mendeteksi game foreground, memprediksi beban thread kritis (schedstat) tiap ~8 ms,
//! lalu menaikkan uclamp CPU + frekuensi minimum GPU secara bertingkat SEBELUM frame telat.

use std::collections::{HashMap, HashSet};
use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::thread::sleep;
use std::time::{Duration, Instant};

extern "C" {
    fn sched_setaffinity(pid: i32, cpusetsize: usize, mask: *const u64) -> i32;
    fn setpriority(which: i32, who: u32, prio: i32) -> i32;
}

const CFG_DIR: &str = "/data/adb/frameboost";
const UCL: [u32; 3] = [20, 35, 50]; // uclamp.min dasar per level (%)
const MID: [u64; 3] = [40, 60, 80]; // min freq cluster tengah (% max)
const PRIME: [u64; 3] = [0, 40, 60]; // min freq cluster prime (% max)
const GPU_BASE: [u64; 3] = [30, 50, 70]; // min freq GPU dasar (% max)
const UCL_ADD: [u32; 4] = [0, 15, 30, 55]; // tambahan uclamp per bucket
const GPU_B: [u64; 4] = [0, 60, 80, 100]; // GPU % per bucket
const UI_BASE: u32 = 10;
const TICK_MS: u64 = 8;

fn log(msg: &str) {
    eprintln!("[fbd] {}", msg);
}

fn wr(p: &Path, v: &str) -> bool {
    fs::write(p, v).is_ok()
}

fn rd(p: &Path) -> Option<String> {
    fs::read_to_string(p).ok().map(|s| s.trim().to_string())
}

fn rd_u64(p: &Path) -> Option<u64> {
    rd(p).and_then(|s| s.parse().ok())
}

// ---------------------------------------------------------------- config

struct Cfg {
    games: HashSet<String>,
    level: usize,
    ui: bool,
}

fn valid_pkg(s: &str) -> bool {
    !s.is_empty()
        && s.contains('.')
        && s.chars().all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '.')
}

fn load_cfg() -> Cfg {
    let mut games = HashSet::new();
    if let Ok(t) = fs::read_to_string(format!("{}/games.txt", CFG_DIR)) {
        for l in t.lines() {
            let l = l.trim();
            if l.is_empty() || l.starts_with('#') {
                continue;
            }
            if valid_pkg(l) {
                games.insert(l.to_string());
            }
        }
    }
    let mut level = 1usize;
    let mut ui = false;
    if let Ok(t) = fs::read_to_string(format!("{}/config.txt", CFG_DIR)) {
        for l in t.lines() {
            let mut it = l.splitn(2, '=');
            let k = it.next().unwrap_or("").trim();
            let v = it.next().unwrap_or("").trim();
            match k {
                "level" => {
                    if let Ok(n) = v.parse::<usize>() {
                        level = n.min(2);
                    }
                }
                "ui_smooth" => ui = v == "1" || v == "true",
                _ => {}
            }
        }
    }
    Cfg { games, level, ui }
}

// ---------------------------------------------------------------- saver (restore aman, tahan crash)

struct Saver {
    file: PathBuf,
    items: Vec<(PathBuf, String)>,
}

impl Saver {
    fn new(name: &str) -> Saver {
        Saver { file: PathBuf::from(format!("{}/{}", CFG_DIR, name)), items: Vec::new() }
    }

    fn remember(&mut self, p: &Path) {
        if self.items.iter().any(|(q, _)| q == p) {
            return;
        }
        if let Some(v) = rd(p) {
            self.items.push((p.to_path_buf(), v));
            self.flush();
        }
    }

    fn flush(&self) {
        let mut s = String::new();
        for (p, v) in &self.items {
            s.push_str(&format!("{}\t{}\n", p.display(), v));
        }
        let _ = fs::write(&self.file, s);
    }

    fn restore(&mut self) {
        for (p, v) in self.items.iter().rev() {
            wr(p, v);
        }
        self.items.clear();
        let _ = fs::remove_file(&self.file);
    }

    /// Dipanggil saat daemon start: kembalikan nilai dari sesi sebelumnya yang crash.
    fn recover(name: &str) {
        let f = format!("{}/{}", CFG_DIR, name);
        if let Ok(t) = fs::read_to_string(&f) {
            for l in t.lines().rev() {
                let mut it = l.splitn(2, '\t');
                if let (Some(p), Some(v)) = (it.next(), it.next()) {
                    wr(Path::new(p), v);
                }
            }
            let _ = fs::remove_file(&f);
        }
    }
}

// ---------------------------------------------------------------- hardware

#[derive(PartialEq, Clone, Copy)]
enum Kind {
    Little,
    Mid,
    Prime,
}

struct Pol {
    dir: PathBuf,
    max: u64,
    kind: Kind,
}

struct Gpu {
    dir: PathBuf,
    max: u64,
    freqs: Vec<u64>,
}

impl Gpu {
    /// frekuensi terendah yang >= pct% dari max
    fn step(&self, pct: u64) -> u64 {
        let t = self.max * pct / 100;
        let mut best = self.max;
        for &f in &self.freqs {
            if f >= t && f < best {
                best = f;
            }
        }
        best
    }
}

struct Hw {
    uclamp: Option<PathBuf>,
    latency: Option<PathBuf>,
    pols: Vec<Pol>,
    gpu: Option<Gpu>,
    ncpu: usize,
    big_mask: u64,
}

fn parse_cpus(s: &str) -> u64 {
    let mut m = 0u64;
    for part in s.split_whitespace() {
        if let Ok(c) = part.parse::<u32>() {
            if c < 64 {
                m |= 1u64 << c;
            }
        }
    }
    m
}

fn discover() -> Hw {
    let mut uclamp = None;
    let mut latency = None;
    for base in ["/dev/cpuctl/top-app", "/sys/fs/cgroup/top-app", "/dev/cpuctl/foreground"] {
        let u = Path::new(base).join("cpu.uclamp.min");
        if u.exists() {
            let l = Path::new(base).join("cpu.uclamp.latency_sensitive");
            if l.exists() {
                latency = Some(l);
            }
            uclamp = Some(u);
            break;
        }
    }

    let mut raw: Vec<(PathBuf, u64, u64)> = Vec::new();
    if let Ok(rdir) = fs::read_dir("/sys/devices/system/cpu/cpufreq") {
        for e in rdir.flatten() {
            let name = e.file_name().to_string_lossy().to_string();
            if !name.starts_with("policy") {
                continue;
            }
            let dir = e.path();
            if let Some(max) = rd_u64(&dir.join("cpuinfo_max_freq")) {
                let mask = rd(&dir.join("related_cpus")).map(|s| parse_cpus(&s)).unwrap_or(0);
                raw.push((dir, max, mask));
            }
        }
    }
    let lmax = raw.iter().map(|r| r.1).min().unwrap_or(0);
    let gmax = raw.iter().map(|r| r.1).max().unwrap_or(0);
    let mut pols = Vec::new();
    let mut big_mask = 0u64;
    let mut all_mask = 0u64;
    for (dir, max, mask) in raw {
        all_mask |= mask;
        let kind = if lmax != gmax && max == lmax {
            Kind::Little
        } else if max == gmax {
            Kind::Prime
        } else {
            Kind::Mid
        };
        if kind != Kind::Little {
            big_mask |= mask;
        }
        pols.push(Pol { dir, max, kind });
    }
    if big_mask == 0 {
        big_mask = all_mask;
    }

    let mut ncpu = 0usize;
    if let Ok(rdir) = fs::read_dir("/sys/devices/system/cpu") {
        for e in rdir.flatten() {
            let n = e.file_name().to_string_lossy().to_string();
            if n.starts_with("cpu") && n[3..].chars().all(|c| c.is_ascii_digit()) && n.len() > 3 {
                ncpu += 1;
            }
        }
    }
    if ncpu == 0 || ncpu > 64 {
        ncpu = 8;
    }

    let gdir = PathBuf::from("/sys/class/kgsl/kgsl-3d0/devfreq");
    let gpu = if gdir.exists() {
        rd_u64(&gdir.join("max_freq")).map(|max| {
            let freqs = rd(&gdir.join("available_frequencies"))
                .map(|s| s.split_whitespace().filter_map(|x| x.parse::<u64>().ok()).collect::<Vec<u64>>())
                .unwrap_or_default();
            Gpu { dir: gdir.clone(), max, freqs }
        })
    } else {
        None
    };

    log(&format!(
        "hw: uclamp={} gpu={} policies={} ncpu={} big_mask={:x}",
        uclamp.is_some(),
        gpu.is_some(),
        pols.len(),
        ncpu,
        big_mask
    ));
    Hw { uclamp, latency, pols, gpu, ncpu, big_mask }
}

// ---------------------------------------------------------------- threads

fn critical_thread(tid: i32, pid: i32, comm: &str) -> bool {
    tid == pid
        || comm == "RenderThread"
        || comm == "UnityMain"
        || comm == "GameThread"
        || comm == "RHIThread"
        || comm.starts_with("UnityGfx")
        || comm.starts_with("UnrealRHI")
        || comm.starts_with("mali-")
}

fn list_threads(pid: i32) -> Vec<i32> {
    let mut v = Vec::new();
    if let Ok(rdir) = fs::read_dir(format!("/proc/{}/task", pid)) {
        for e in rdir.flatten() {
            if let Ok(tid) = e.file_name().to_string_lossy().parse::<i32>() {
                let comm = rd(&e.path().join("comm")).unwrap_or_default();
                if critical_thread(tid, pid, &comm) {
                    v.push(tid);
                }
            }
        }
    }
    v
}

fn set_affinity(tid: i32, mask: u64) {
    unsafe {
        sched_setaffinity(tid, 8, &mask as *const u64);
    }
}

fn set_nice(tid: i32, nice: i32) {
    unsafe {
        setpriority(0, tid as u32, nice);
    }
}

fn schedstat_run(tid: i32, pid: i32) -> Option<u64> {
    let t = fs::read_to_string(format!("/proc/{}/task/{}/schedstat", pid, tid)).ok()?;
    t.split_whitespace().next()?.parse().ok()
}

fn spawn_cmd(args: Vec<String>) {
    std::thread::spawn(move || {
        let _ = Command::new("cmd").args(&args).output();
    });
}

// ---------------------------------------------------------------- session

struct Session {
    pkg: String,
    pid: i32,
    lvl: usize,
    saver: Saver,
    watch: Vec<i32>,
    last: HashMap<i32, u64>,
    last_wall: Option<Instant>,
    last_scan: Instant,
    prev_load: f64,
    bucket: i32,
    low_since: Option<Instant>,
}

impl Session {
    fn start(hw: &Hw, cfg: &Cfg, pkg: &str, pid: i32) -> Session {
        let lvl = cfg.level;
        let mut saver = Saver::new("state_game");
        if let Some(u) = &hw.uclamp {
            saver.remember(u);
        }
        if let Some(l) = &hw.latency {
            saver.remember(l);
            wr(l, "1");
        }
        for p in &hw.pols {
            let f = p.dir.join("scaling_min_freq");
            saver.remember(&f);
            let pct = match p.kind {
                Kind::Little => 0,
                Kind::Mid => MID[lvl],
                Kind::Prime => PRIME[lvl],
            };
            if pct > 0 {
                wr(&f, &(p.max * pct / 100).to_string());
            }
        }
        if let Some(g) = &hw.gpu {
            saver.remember(&g.dir.join("min_freq"));
        }

        let watch = list_threads(pid);
        for &t in &watch {
            set_affinity(t, hw.big_mask);
            set_nice(t, -6);
        }

        spawn_cmd(vec!["game".into(), "mode".into(), "performance".into(), pkg.to_string()]);
        log(&format!("START {} pid={} level={} threads={}", pkg, pid, lvl, watch.len()));

        let mut s = Session {
            pkg: pkg.to_string(),
            pid,
            lvl,
            saver,
            watch,
            last: HashMap::new(),
            last_wall: None,
            last_scan: Instant::now(),
            prev_load: 0.0,
            bucket: -1,
            low_since: None,
        };
        s.apply_bucket(hw, 0);
        s
    }

    fn apply_bucket(&mut self, hw: &Hw, b: i32) {
        let bi = b.clamp(0, 3) as usize;
        if let Some(u) = &hw.uclamp {
            let v = (UCL[self.lvl] + UCL_ADD[bi]).min(95);
            wr(u, &v.to_string());
        }
        if let Some(g) = &hw.gpu {
            let pct = GPU_BASE[self.lvl].max(GPU_B[bi]);
            wr(&g.dir.join("min_freq"), &g.step(pct).to_string());
        }
        self.bucket = b;
    }

    /// Satu langkah prediktor. Dipanggil tiap TICK_MS.
    fn tick(&mut self, hw: &Hw) {
        let now = Instant::now();
        if now.duration_since(self.last_scan) > Duration::from_secs(2) {
            let fresh = list_threads(self.pid);
            for &t in &fresh {
                if !self.watch.contains(&t) {
                    set_affinity(t, hw.big_mask);
                    set_nice(t, -6);
                }
            }
            self.watch = fresh;
            self.last_scan = now;
        }

        let mut load = 0.0f64;
        match self.last_wall {
            Some(lw) => {
                let wall = now.duration_since(lw).as_nanos() as f64;
                for &t in &self.watch {
                    if let Some(run) = schedstat_run(t, self.pid) {
                        if let Some(prev) = self.last.insert(t, run) {
                            if wall > 0.0 && run >= prev {
                                load = load.max((run - prev) as f64 / wall);
                            }
                        }
                    }
                }
            }
            None => {
                for &t in &self.watch {
                    if let Some(run) = schedstat_run(t, self.pid) {
                        self.last.insert(t, run);
                    }
                }
            }
        }
        self.last_wall = Some(now);

        // prediksi: beban sekarang + ekstrapolasi kenaikan
        let pred = (load + 1.5 * (load - self.prev_load).max(0.0)).min(1.0);
        self.prev_load = load;
        let b: i32 = if pred > 0.85 {
            3
        } else if pred > 0.65 {
            2
        } else if pred > 0.40 {
            1
        } else {
            0
        };

        if b >= self.bucket {
            self.low_since = None;
            if b != self.bucket {
                self.apply_bucket(hw, b);
            }
        } else {
            // turun harus stabil 300 ms
            let since = *self.low_since.get_or_insert(now);
            if now.duration_since(since) > Duration::from_millis(300) {
                self.low_since = None;
                self.apply_bucket(hw, b);
            }
        }
    }

    fn stop(mut self, hw: &Hw) {
        self.saver.restore();
        let all: u64 = if hw.ncpu >= 64 { u64::MAX } else { (1u64 << hw.ncpu) - 1 };
        for &t in &self.watch {
            set_affinity(t, all);
            set_nice(t, 0);
        }
        spawn_cmd(vec!["game".into(), "reset".into(), self.pkg.clone()]);
        log(&format!("STOP {}", self.pkg));
    }
}

// ---------------------------------------------------------------- foreground

fn pkg_of(pid: i32) -> Option<String> {
    let b = fs::read(format!("/proc/{}/cmdline", pid)).ok()?;
    let end = b.iter().position(|&c| c == 0).unwrap_or(b.len());
    Some(String::from_utf8_lossy(&b[..end]).to_string())
}

fn is_foreground(pid: i32) -> bool {
    rd(Path::new(&format!("/proc/{}/oom_score_adj", pid))).as_deref() == Some("0")
}

fn find_fg(cfg: &Cfg) -> Option<(String, i32)> {
    if cfg.games.is_empty() {
        return None;
    }
    for e in fs::read_dir("/proc").ok()?.flatten() {
        if let Ok(pid) = e.file_name().to_string_lossy().parse::<i32>() {
            if let Some(name) = pkg_of(pid) {
                if cfg.games.contains(&name) && is_foreground(pid) {
                    return Some((name, pid));
                }
            }
        }
    }
    None
}

// ---------------------------------------------------------------- main

fn main() {
    let _ = fs::create_dir_all(CFG_DIR);
    Saver::recover("state_game");
    Saver::recover("state_ui");
    let hw = discover();

    let mut sess: Option<Session> = None;
    let mut ui_saver = Saver::new("state_ui");
    let mut ui_on = false;
    let mut last_check = Instant::now() - Duration::from_secs(10);
    let mut cfg = load_cfg();

    log("daemon siap");
    loop {
        match sess.as_mut() {
            None => {
                cfg = load_cfg();

                // baseline UI smooth
                if let Some(u) = &hw.uclamp {
                    if cfg.ui && !ui_on {
                        ui_saver.remember(u);
                        wr(u, &UI_BASE.to_string());
                        ui_on = true;
                    } else if !cfg.ui && ui_on {
                        ui_saver.restore();
                        ui_on = false;
                    }
                }

                if let Some((pkg, pid)) = find_fg(&cfg) {
                    sess = Some(Session::start(&hw, &cfg, &pkg, pid));
                    last_check = Instant::now();
                } else {
                    sleep(Duration::from_millis(1000));
                }
            }
            Some(s) => {
                s.tick(&hw);
                if last_check.elapsed() > Duration::from_secs(1) {
                    last_check = Instant::now();
                    let alive = pkg_of(s.pid).as_deref() == Some(s.pkg.as_str());
                    if !alive || !is_foreground(s.pid) {
                        if let Some(done) = sess.take() {
                            done.stop(&hw);
                        }
                        // kembalikan baseline UI jika aktif
                        if ui_on {
                            if let Some(u) = &hw.uclamp {
                                wr(u, &UI_BASE.to_string());
                            }
                        }
                        continue;
                    }
                }
                sleep(Duration::from_millis(TICK_MS));
            }
        }
        let _ = std::io::stderr().flush();
    }
}
