package com.frameboost.lsp;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

final class Root {
    private static Process proc;
    private static OutputStream out;

    /** One-shot: jalankan script dan tunggu hasilnya. */
    static String run(String script) {
        try {
            Process p = new ProcessBuilder("su").redirectErrorStream(true).start();
            try (OutputStream os = p.getOutputStream()) {
                os.write((script + "\nexit\n").getBytes());
            }
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            try (InputStream is = p.getInputStream()) {
                byte[] b = new byte[4096];
                int n;
                while ((n = is.read(b)) > 0) bo.write(b, 0, n);
            }
            p.waitFor();
            return bo.toString();
        } catch (Exception e) {
            return "ERR " + e;
        }
    }

    static boolean available() { return run("id -u").trim().endsWith("0"); }

    /** Root shell persisten: perintah ditulis langsung tanpa spawn proses su baru (latensi ~ms). */
    static synchronized void fire(String cmd) {
        try {
            if (proc == null || !proc.isAlive()) {
                proc = new ProcessBuilder("su").redirectErrorStream(true).start();
                out = proc.getOutputStream();
                final InputStream is = proc.getInputStream();
                new Thread(() -> { try { byte[] b = new byte[1024]; while (is.read(b) > 0) { } } catch (Exception ignored) {} }).start();
                out.write(Tuner.INIT.getBytes());
            }
            out.write((cmd + "\n").getBytes());
            out.flush();
        } catch (Exception e) {
            proc = null;
        }
    }
}
