package com.frameboost.lsp;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Set;

public class MainActivity extends Activity {
    private Config cfg;
    private LinearLayout list;
    private TextView status;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        cfg = new Config(this);
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(32), dp(16), dp(16));
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("FrameBoost LSP");
        title.setTextSize(24);
        root.addView(title);

        status = new TextView(this);
        status.setText("Cek root...");
        root.addView(status);
        new Thread(() -> {
            final boolean ok = Root.available();
            runOnUiThread(() -> status.setText(ok ? "Root: OK" : "Root: TIDAK ADA (beri akses su ke app ini)"));
        }).start();

        Switch en = new Switch(this);
        en.setText("Aktifkan module");
        en.setChecked(cfg.enabled());
        en.setOnCheckedChangeListener((v, on) -> cfg.enabled(on));
        root.addView(en);

        Switch ui = new Switch(this);
        ui.setText("UI smooth (baseline uclamp ringan)");
        ui.setChecked(cfg.ui());
        ui.setOnCheckedChangeListener((v, on) -> {
            cfg.ui(on);
            new Thread(() -> { if (on) Tuner.uiOn(); else Tuner.uiOff(); }).start();
        });
        root.addView(ui);

        TextView lt = new TextView(this);
        lt.setText("\nLevel gaming boost");
        root.addView(lt);
        RadioGroup rg = new RadioGroup(this);
        String[] names = {"Low (hemat)", "Medium", "High (agresif)"};
        for (int i = 0; i < 3; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(names[i]);
            rb.setId(100 + i);
            rg.addView(rb);
        }
        rg.check(100 + cfg.level());
        rg.setOnCheckedChangeListener((g, id) -> cfg.level(id - 100));
        root.addView(rg);

        TextView gt = new TextView(this);
        gt.setText("\nDaftar game (package name)");
        root.addView(gt);

        LinearLayout add = new LinearLayout(this);
        final EditText et = new EditText(this);
        et.setHint("com.tencent.ig");
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        add.addView(et, new LinearLayout.LayoutParams(0, -2, 1));
        Button ab = new Button(this);
        ab.setText("Tambah");
        ab.setOnClickListener(v -> {
            String s = et.getText().toString().trim();
            if (!Config.PKG.matcher(s).matches()) {
                Toast.makeText(this, "Package name tidak valid", Toast.LENGTH_SHORT).show();
                return;
            }
            Set<String> g = cfg.games(); g.add(s); cfg.games(g);
            et.setText("");
            refresh();
        });
        add.addView(ab);
        root.addView(add);

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        Button reset = new Button(this);
        reset.setText("Reset semua tweak sekarang");
        reset.setOnClickListener(v -> new Thread(() -> {
            Tuner.restore(); cfg.active("");
            if (cfg.ui()) Tuner.uiOn();
            runOnUiThread(() -> Toast.makeText(this, "Di-reset", Toast.LENGTH_SHORT).show());
        }).start());
        root.addView(reset);

        TextView hint = new TextView(this);
        hint.setText("\nPenting: aktifkan module di LSPosed, lalu centang SETIAP game di scope module ini. " +
                "Setelah itu force-stop game dan buka lagi.");
        root.addView(hint);

        refresh();
        setContentView(sv);
    }

    private void refresh() {
        list.removeAllViews();
        for (final String p : cfg.games()) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView t = new TextView(this);
            t.setText(p);
            row.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
            Button d = new Button(this);
            d.setText("Hapus");
            d.setOnClickListener((View v) -> {
                Set<String> g = cfg.games(); g.remove(p); cfg.games(g);
                refresh();
            });
            row.addView(d);
            list.addView(row);
        }
    }
}
