package com.frameboost.lsp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent i) {
        final Config c = new Config(ctx);
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                Tuner.wipeState();
                c.active("");
                if (c.enabled() && c.ui()) Tuner.uiOn();
            } finally { pr.finish(); }
        }).start();
    }
}
