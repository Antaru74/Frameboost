package com.frameboost.lsp;

/** Semua tweak userspace dijalankan lewat root shell. Kernel path bisa beda per ROM — script sudah dibuat defensif. */
final class Tuner {
    // Level 0=Low 1=Medium 2=High
    static final int[] UCL   = {20, 35, 50};   // top-app uclamp.min (%)
    static final int[] MID   = {40, 60, 80};   // min freq cluster tengah (% dari max)
    static final int[] PRIME = { 0, 40, 60};   // min freq cluster prime (% dari max)
    static final int[] JANK  = {70, 80, 90};   // uclamp.min sesaat saat jank
    static final int[] GPU   = {30, 50, 70};   // min freq GPU (% dari max)
    static final int JANK_MS = 400;
    static final int UI_BASE = 10;

    private static final String HEAD = """
        D=/data/local/tmp/frameboost
        mkdir -p $D
        TA=/dev/cpuctl/top-app
        [ -d $TA ] || TA=/sys/fs/cgroup/top-app
        """;

    /** Dijalankan sekali saat root shell persisten dibuka. */
    static final String INIT = """
        D=/data/local/tmp/frameboost
        mkdir -p $D
        TA=/dev/cpuctl/top-app
        [ -d $TA ] || TA=/sys/fs/cgroup/top-app
        G=/sys/class/kgsl/kgsl-3d0/devfreq
        GMAX=$(cat $G/max_freq 2>/dev/null)
        gf() { T=$((GMAX*$1/100)); F=$GMAX; for f in $(cat $G/available_frequencies 2>/dev/null); do if [ $f -ge $T ] && [ $f -lt $F ]; then F=$f; fi; done; echo $F; }
        if [ -n "$GMAX" ]; then GF1=$(gf 60); GF2=$(gf 80); GF3=$GMAX; fi
        """;

    private static final java.util.concurrent.ScheduledExecutorService EX =
        java.util.concurrent.Executors.newSingleThreadScheduledExecutor();
    private static java.util.concurrent.ScheduledFuture<?> pending;

    private static final String APPLY = """
        PKG=@PKG@; PID=@PID@; UCL=@UCL@; MIDP=@MID@; PRIMEP=@PRIME@; GPCT=@GPU@
        G=/sys/class/kgsl/kgsl-3d0/devfreq
        if [ -d $G ]; then
          [ -f $D/gmin ] || cat $G/min_freq > $D/gmin
          GM=$(cat $G/max_freq); T=$((GM*GPCT/100)); F=$GM
          for f in $(cat $G/available_frequencies 2>/dev/null); do
            if [ $f -ge $T ] && [ $f -lt $F ]; then F=$f; fi
          done
          if [ $GPCT -gt 0 ]; then echo $F > $G/min_freq 2>/dev/null; echo $F > $D/gfloor; else cat $D/gmin > $D/gfloor; fi
        fi
        [ -f $D/ucl ] || cat $TA/cpu.uclamp.min > $D/ucl 2>/dev/null
        echo $UCL > $TA/cpu.uclamp.min 2>/dev/null
        [ -e $TA/cpu.uclamp.latency_sensitive ] && echo 1 > $TA/cpu.uclamp.latency_sensitive 2>/dev/null
        LMAX=999999999; GMAX=0
        for P in /sys/devices/system/cpu/cpufreq/policy*; do
          m=$(cat $P/cpuinfo_max_freq)
          [ $m -lt $LMAX ] && LMAX=$m
          [ $m -gt $GMAX ] && GMAX=$m
        done
        BIG=0
        for P in /sys/devices/system/cpu/cpufreq/policy*; do
          n=${P##*policy}; m=$(cat $P/cpuinfo_max_freq)
          [ -f $D/f_$n ] || cat $P/scaling_min_freq > $D/f_$n
          if [ $m -eq $LMAX ] && [ $LMAX -ne $GMAX ]; then continue; fi
          if [ $m -eq $GMAX ]; then pct=$PRIMEP; else pct=$MIDP; fi
          [ $pct -gt 0 ] && echo $((m*pct/100)) > $P/scaling_min_freq 2>/dev/null
          for c in $(cat $P/related_cpus); do BIG=$((BIG | (1<<c))); done
        done
        MASK=$(printf '%x' $BIG)
        echo $PKG > $D/pkg
        CMD=$(tr '\\0' ' ' < /proc/$PID/cmdline 2>/dev/null | cut -d' ' -f1)
        if [ "$CMD" = "$PKG" ] && [ "$(cat $D/pid 2>/dev/null)" != "$PID" ]; then
          echo $PID > $D/pid; : > $D/tids
          for T in /proc/$PID/task/*; do
            t=${T##*/}; c=$(cat $T/comm 2>/dev/null)
            case "$c" in
              RenderThread|UnityMain|UnityGfx*|GameThread|RHIThread|UnrealRHI*|mali-*) ;;
              *) [ "$t" = "$PID" ] || continue ;;
            esac
            taskset -p $MASK $t >/dev/null 2>&1
            renice -n -6 -p $t >/dev/null 2>&1
            echo $t >> $D/tids
          done
        fi
        cmd game mode performance $PKG >/dev/null 2>&1
        """;

    private static final String RESTORE = """
        G=/sys/class/kgsl/kgsl-3d0/devfreq
        [ -f $D/gmin ] && { cat $D/gmin > $G/min_freq 2>/dev/null; rm -f $D/gmin $D/gfloor; }
        [ -f $D/ucl ] && { cat $D/ucl > $TA/cpu.uclamp.min 2>/dev/null; rm -f $D/ucl; }
        for f in $D/f_*; do
          [ -f "$f" ] || continue
          n=${f##*/f_}
          cat $f > /sys/devices/system/cpu/cpufreq/policy$n/scaling_min_freq 2>/dev/null
          rm -f $f
        done
        NC=$(ls /sys/devices/system/cpu | grep -c '^cpu[0-9]')
        ALL=$(printf '%x' $(( (1<<NC)-1 )))
        for t in $(cat $D/tids 2>/dev/null); do
          taskset -p $ALL $t >/dev/null 2>&1
          renice -n 6 -p $t >/dev/null 2>&1
        done
        [ -f $D/pkg ] && cmd game reset $(cat $D/pkg) >/dev/null 2>&1
        rm -f $D/pid $D/tids $D/pkg
        """;

    private static final String UI_ON = """
        [ -f $D/ui_orig ] || cat $TA/cpu.uclamp.min > $D/ui_orig 2>/dev/null
        echo @V@ > $TA/cpu.uclamp.min 2>/dev/null
        """;

    private static final String UI_OFF = """
        [ -f $D/ui_orig ] && { cat $D/ui_orig > $TA/cpu.uclamp.min 2>/dev/null; rm -f $D/ui_orig; }
        """;

    static synchronized String apply(String pkg, int pid, int lvl) {
        return Root.run(HEAD + APPLY.replace("@PKG@", pkg).replace("@PID@", String.valueOf(pid))
                .replace("@UCL@", String.valueOf(UCL[lvl])).replace("@MID@", String.valueOf(MID[lvl]))
                .replace("@PRIME@", String.valueOf(PRIME[lvl])).replace("@GPU@", String.valueOf(GPU[lvl])));
    }
    static synchronized String restore() {
        if (pending != null) pending.cancel(false);
        return Root.run(HEAD + RESTORE);
    }

    /** Bucket beban hasil prediksi: 0 normal, 1 ringan, 2 sedang, 3 berat. Dipanggil dari hook sebelum frame telat. */
    static void bucket(int lvl, int b) {
        synchronized (Tuner.class) { if (pending != null) pending.cancel(false); }
        if (b <= 0) {
            Root.fire("echo " + UCL[lvl] + " > $TA/cpu.uclamp.min; [ -f $D/gfloor ] && cat $D/gfloor > $G/min_freq");
            return;
        }
        int u = Math.min(95, UCL[lvl] + new int[]{0, 15, 30, 55}[b]);
        Root.fire("echo " + u + " > $TA/cpu.uclamp.min; [ -n \"$GMAX\" ] && echo $GF" + b + " > $G/min_freq");
    }

    /** Boost instan lewat root shell persisten (tanpa spawn su), lalu turun lagi setelah JANK_MS. */
    static void jank(int lvl) {
        Root.fire("echo " + JANK[lvl] + " > $TA/cpu.uclamp.min; [ -n \"$GMAX\" ] && echo $GMAX > $G/min_freq");
        synchronized (Tuner.class) {
            if (pending != null) pending.cancel(false);
            final int l = lvl;
            pending = EX.schedule(() -> Root.fire("echo " + UCL[l] + " > $TA/cpu.uclamp.min; [ -f $D/gfloor ] && cat $D/gfloor > $G/min_freq"),
                JANK_MS, java.util.concurrent.TimeUnit.MILLISECONDS);
        }
    }
    static synchronized String uiOn() { return Root.run(HEAD + UI_ON.replace("@V@", String.valueOf(UI_BASE))); }
    static synchronized String uiOff() { return Root.run(HEAD + UI_OFF); }
    static synchronized String wipeState() { return Root.run("rm -rf /data/local/tmp/frameboost"); }
}
