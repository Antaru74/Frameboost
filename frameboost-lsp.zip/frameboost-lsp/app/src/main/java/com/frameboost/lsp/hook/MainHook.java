package com.frameboost.lsp.hook;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Process;
import android.view.Choreographer;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/** Jalan di dalam proses game (scope LSPosed). Mengirim sinyal ACTIVE / INACTIVE / JANK ke app module. */
public class MainHook implements IXposedHookLoadPackage {
    private static final String MOD = "com.frameboost.lsp";
    private static final AtomicInteger resumed = new AtomicInteger();
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static volatile double period = 1e9 / 120.0;
    private static long lastStart, lastSent;
    private static boolean prevContinuous;

    @Override
    public void handleLoadPackage(LoadPackageParam lp) {
        if (lp.packageName.equals(MOD) || lp.packageName.equals("android")) return;
        if (!lp.processName.equals(lp.packageName)) return; // hanya proses utama

        XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                try {
                    Activity a = (Activity) p.thisObject;
                    float hz = a.getWindowManager().getDefaultDisplay().getRefreshRate();
                    if (hz > 20) period = 1e9 / hz;
                } catch (Throwable ignored) {}
                resumed.incrementAndGet();
                send("ACTIVE");
                Sampler.start();
            }
        });

        XposedHelpers.findAndHookMethod(Activity.class, "onPause", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                resumed.decrementAndGet();
                H.postDelayed(() -> { if (resumed.get() <= 0) { Sampler.stop(); send("INACTIVE"); } }, 1500);
            }
        });

        try {
            XposedBridge.hookAllMethods(Choreographer.class, "doFrame", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    p.setObjectExtra("t0", System.nanoTime());
                }
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    Object o = p.getObjectExtra("t0");
                    if (o == null) return;
                    long t0 = (Long) o, now = System.nanoTime();
                    long dur = now - t0;
                    long gap = lastStart > 0 ? t0 - lastStart : 0;
                    lastStart = t0;
                    boolean continuous = gap > 0 && gap < period * 1.6;
                    boolean jank = dur > period * 0.9
                            || (prevContinuous && gap > period * 1.7 && gap < period * 8);
                    prevContinuous = continuous;
                    if (jank && now - lastSent > 250_000_000L) { lastSent = now; send("JANK"); }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("FrameBoost: hook Choreographer gagal: " + t);
        }
    }

    /** Prediktor beban: sampling runtime thread kritis tiap ~10 ms, ekstrapolasi tren, kirim bucket hanya saat berubah. */
    static final class Sampler implements Runnable {
        private static HandlerThread ht;
        private static Handler h;
        private static final Sampler I = new Sampler();
        private final Map<Integer, Long> last = new HashMap<>();
        private int[] tids = new int[0];
        private long lastWall, lastScan, lowSince;
        private double prevLoad;
        private int bucket = -1;

        static synchronized void start() {
            if (ht != null) return;
            ht = new HandlerThread("fb-sampler"); ht.start();
            h = new Handler(ht.getLooper());
            I.last.clear(); I.lastWall = 0; I.bucket = -1; I.prevLoad = 0;
            h.post(I);
        }
        static synchronized void stop() {
            if (ht == null) return;
            ht.quitSafely(); ht = null; h = null;
        }

        private void scan() {
            File[] fs = new File("/proc/self/task").listFiles();
            if (fs == null) return;
            int[] tmp = new int[fs.length]; int n = 0, me = Process.myPid();
            for (File f : fs) {
                try {
                    int t = Integer.parseInt(f.getName());
                    String c = new String(read(new File(f, "comm"))).trim();
                    if (t == me || c.equals("RenderThread") || c.equals("UnityMain") || c.startsWith("UnityGfx")
                            || c.equals("GameThread") || c.equals("RHIThread") || c.startsWith("UnrealRHI"))
                        tmp[n++] = t;
                } catch (Throwable ignored) {}
            }
            tids = java.util.Arrays.copyOf(tmp, n);
        }

        private static byte[] read(File f) throws Exception {
            try (FileInputStream in = new FileInputStream(f)) {
                byte[] b = new byte[64]; int n = in.read(b);
                return java.util.Arrays.copyOf(b, Math.max(n, 0));
            }
        }

        @Override public void run() {
            Handler hh = h; if (hh == null) return;
            long now = System.nanoTime();
            if (now - lastScan > 2_000_000_000L) { scan(); lastScan = now; }
            double load = 0;
            if (lastWall > 0) {
                long wall = now - lastWall;
                for (int t : tids) {
                    try {
                        String[] f = new String(read(new File("/proc/self/task/" + t + "/schedstat"))).trim().split(" ");
                        long run = Long.parseLong(f[0]);
                        Long prev = last.put(t, run);
                        if (prev != null && wall > 0) load = Math.max(load, (double) (run - prev) / wall);
                    } catch (Throwable ignored) {}
                }
            } else {
                for (int t : tids) try {
                    last.put(t, Long.parseLong(new String(read(new File("/proc/self/task/" + t + "/schedstat"))).trim().split(" ")[0]));
                } catch (Throwable ignored) {}
            }
            lastWall = now;
            // prediksi: beban sekarang + ekstrapolasi kenaikan (naik cepat -> boost lebih awal)
            double pred = Math.min(1.0, load + 1.5 * Math.max(0, load - prevLoad));
            prevLoad = load;
            int b = pred > 0.85 ? 3 : pred > 0.65 ? 2 : pred > 0.40 ? 1 : 0;
            if (b >= bucket) { lowSince = 0; if (b != bucket) { bucket = b; sendLoad(b); } }
            else { // turun harus stabil 300 ms (hindari flapping)
                if (lowSince == 0) lowSince = now;
                if (now - lowSince > 300_000_000L) { bucket = b; lowSince = 0; sendLoad(b); }
            }
            hh.postDelayed(this, 10);
        }
    }

    private static void sendLoad(int b) {
        try {
            Application app = (Application) XposedHelpers.callStaticMethod(
                    XposedHelpers.findClass("android.app.ActivityThread", null), "currentApplication");
            if (app == null) return;
            app.sendBroadcast(new Intent(MOD + ".LOAD").setPackage(MOD)
                    .putExtra("pkg", app.getPackageName()).putExtra("pid", Process.myPid()).putExtra("b", b));
        } catch (Throwable t) { XposedBridge.log("FrameBoost: sendLoad gagal: " + t); }
    }

    private static void send(String action) {
        try {
            Application app = (Application) XposedHelpers.callStaticMethod(
                    XposedHelpers.findClass("android.app.ActivityThread", null), "currentApplication");
            if (app == null) return;
            Context c = app;
            Intent i = new Intent(MOD + "." + action).setPackage(MOD)
                    .putExtra("pkg", c.getPackageName()).putExtra("pid", Process.myPid());
            c.sendBroadcast(i);
        } catch (Throwable t) {
            XposedBridge.log("FrameBoost: send gagal: " + t);
        }
    }
}
