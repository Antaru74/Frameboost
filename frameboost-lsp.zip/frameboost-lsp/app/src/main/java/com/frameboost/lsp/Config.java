package com.frameboost.lsp;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Pattern;

final class Config {
    static final Pattern PKG = Pattern.compile("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$");
    private final SharedPreferences p;

    Config(Context c) { p = c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }

    boolean enabled() { return p.getBoolean("en", true); }
    void enabled(boolean v) { p.edit().putBoolean("en", v).apply(); }
    boolean ui() { return p.getBoolean("ui", false); }
    void ui(boolean v) { p.edit().putBoolean("ui", v).apply(); }
    int level() { return p.getInt("lvl", 1); }
    void level(int v) { p.edit().putInt("lvl", v).apply(); }
    String active() { return p.getString("active", ""); }
    void active(String s) { p.edit().putString("active", s).apply(); }

    Set<String> games() {
        return new TreeSet<>(p.getStringSet("games", new HashSet<>()));
    }
    void games(Set<String> s) { p.edit().putStringSet("games", new HashSet<>(s)).apply(); }
}
