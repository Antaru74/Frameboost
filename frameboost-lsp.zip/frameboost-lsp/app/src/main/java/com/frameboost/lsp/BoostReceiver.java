package com.frameboost.lsp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BoostReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent i) {
        final Config c = new Config(ctx);
        if (!c.enabled() || i.getAction() == null) return;
        final String pkg = i.getStringExtra("pkg");
        final int pid = i.getIntExtra("pid", -1);
        if (pkg == null || !Config.PKG.matcher(pkg).matches() || !c.games().contains(pkg)) return;
        final String act = i.getAction();
        if (act.endsWith(".LOAD")) {
            if (pkg.equals(c.active()))
                Tuner.bucket(Math.max(0, Math.min(2, c.level())), Math.max(0, Math.min(3, i.getIntExtra("b", 0))));
            return;
        }
        if (act.endsWith(".JANK")) {
            if (pkg.equals(c.active())) Tuner.jank(Math.max(0, Math.min(2, c.level())));
            return;
        }
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                int lvl = Math.max(0, Math.min(2, c.level()));
                if (act.endsWith(".ACTIVE") && pid > 0) {
                    Tuner.apply(pkg, pid, lvl);
                    c.active(pkg);
                } else if (act.endsWith(".INACTIVE")) {
                    if (pkg.equals(c.active())) { Tuner.restore(); c.active(""); }
                }
            } finally { pr.finish(); }
        }).start();
    }
}
