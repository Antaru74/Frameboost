# FrameBoost LSP

Pendekatan userspace (bukan kernel) untuk meniru ide frame_boost / sched_assist / uad dari OPLUS.

## Build
1. Buka folder ini di Android Studio (JDK 17), biarkan Gradle sync, lalu Build > Build APK.
2. Install APK, buka sekali.
3. LSPosed > Modul > aktifkan FrameBoost LSP > centang scope: setiap game yang dipakai.
4. Buka app, beri akses root (KernelSU/Magisk), tambahkan package name game, pilih level.
5. Force-stop game, buka lagi. Matikan battery optimization untuk app ini.

## Cara kerja
- Hook di proses game: Activity.onResume/onPause -> sinyal ACTIVE/INACTIVE; Choreographer.doFrame -> deteksi jank.
- App module (root) saat ACTIVE: naikkan cpu.uclamp.min top-app, naikkan min freq cluster tengah/prime,
  pin RenderThread/UnityMain/GameThread/main thread ke core tengah+prime, renice, `cmd game mode performance`.
- Saat JANK: uclamp + GPU min freq ke max selama 400 ms (lewat root shell persisten). Saat INACTIVE: semua dikembalikan.
- "UI smooth": baseline uclamp.min kecil di top-app (persist tiap boot).

## Prediksi beban (v2)
Sampler di proses game membaca /proc/self/task/<tid>/schedstat thread kritis (main, RenderThread, UnityMain, GameThread, RHI)
tiap ~10 ms, menghitung beban + tren naik, lalu memilih bucket 0-3. Bucket dikirim ke module hanya saat berubah
(naik langsung, turun setelah stabil 300 ms). Module menerjemahkannya ke uclamp bertingkat + min freq GPU bertingkat.
