//! fbd - FrameBoost daemon (root, native).
//! Mendeteksi game foreground, memprediksi beban thread kritis (schedstat) tiap ~8 ms,
//! lalu menaikkan uclamp CPU + frekuensi minimum GPU secara bertingkat SEBELUM frame telat.

use std::collections::{HashMap, HashSet};
use std::fs;
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::os::unix::fs::{MetadataExt, OpenOptionsExt};
use std::process::Command;
use std::thread::sleep;
use std::time::{Duration, Instant};

extern "C" {
    fn sched_setaffinity(pid: i32, cpusetsize: usize, mask: *const u64) -> i32;
    fn setpriority(which: i32, who: u32, prio: i32) -> i32;
}

const CFG_DIR: &str = "/data/adb/frameboost";
const UCL: [u32; 3] = [20, 35, 50]; // uclamp.min dasar per level (%)
const MID: [u64; 3] = [40, 60, 80]; // min freq cluster tengah (% max)
const PRIME: [u64; 3] = [0, 40, 60]; // min freq cluster prime (% max)
const GPU_BASE: [u64; 3] = [30, 50, 70]; // min freq GPU dasar (% max)
const UCL_ADD: [u32; 4] = [0, 15, 30, 55]; // tambahan uclamp per bucket
const GPU_B: [u64; 4] = [0, 60, 80, 100]; // GPU % per bucket
const UI_BASE: u32 = 10;
const TICK_MS: u64 = 4;
const MID_G: [u64; 4] = [0, 55, 75, 95]; // min freq cluster tengah per bucket (game)
const PRIME_G: [u64; 4] = [0, 45, 70, 100]; // min freq cluster prime per bucket (game)
const UI_ADD: [u32; 4] = [0, 10, 20, 35]; // tambahan uclamp mode UI per bucket
const UI_SCALE: [f64; 3] = [0.6, 1.0, 1.4]; // skala per level
const MID_UI: [u64; 4] = [0, 25, 40, 60]; // min freq cluster tengah mode UI (% max)
const PRIME_UI: [u64; 4] = [0, 0, 30, 50]; // min freq cluster prime mode UI (% max)
const GPU_UI: [u64; 4] = [0, 30, 50, 70]; // GPU min % mode UI (0 = biarkan default)

fn log(msg: &str) {
    eprintln!("[fbd] {}", msg);
}

fn wr(p: &Path, v: &str) -> bool {
    fs::write(p, v).is_ok()
}

fn rd(p: &Path) -> Option<String> {
    fs::read_to_string(p).ok().map(|s| s.trim().to_string())
}

fn rd_u64(p: &Path) -> Option<u64> {
    rd(p).and_then(|s| s.parse().ok())
}

// ---------------------------------------------------------------- config

struct Cfg {
    games: HashSet<String>,
    level: usize,
    ui: bool,
}

fn valid_pkg(s: &str) -> bool {
    !s.is_empty()
        && s.contains('.')
        && s.chars().all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '.')
}

fn load_cfg() -> Cfg {
    let mut games = HashSet::new();
    if let Ok(t) = fs::read_to_string(format!("{}/games.txt", CFG_DIR)) {
        for l in t.lines() {
            let l = l.trim();
            if l.is_empty() || l.starts_with('#') {
                continue;
            }
            if valid_pkg(l) {
                games.insert(l.to_string());
            }
        }
    }
    let mut level = 1usize;
    let mut ui = false;
    if let Ok(t) = fs::read_to_string(format!("{}/config.txt", CFG_DIR)) {
        for l in t.lines() {
            let mut it = l.splitn(2, '=');
            let k = it.next().unwrap_or("").trim();
            let v = it.next().unwrap_or("").trim();
            match k {
                "level" => {
                    if let Ok(n) = v.parse::<usize>() {
                        level = n.min(2);
                    }
                }
                "ui_smooth" => ui = !v.is_empty() && v != "0" && v != "false",
                _ => {}
            }
        }
    }
    Cfg { games, level, ui }
}

// ---------------------------------------------------------------- saver (restore aman, tahan crash)

struct Saver {
    file: PathBuf,
    items: Vec<(PathBuf, String)>,
}

impl Saver {
    fn new(name: &str) -> Saver {
        Saver { file: PathBuf::from(format!("{}/{}", CFG_DIR, name)), items: Vec::new() }
    }

    fn remember(&mut self, p: &Path) {
        if self.items.iter().any(|(q, _)| q == p) {
            return;
        }
        if let Some(v) = rd(p) {
            self.items.push((p.to_path_buf(), v));
            self.flush();
        }
    }

    fn get(&self, p: &Path) -> Option<String> {
        self.items.iter().find(|(q, _)| q == p).map(|(_, v)| v.clone())
    }

    fn flush(&self) {
        let mut s = String::new();
        for (p, v) in &self.items {
            s.push_str(&format!("{}\t{}\n", p.display(), v));
        }
        let _ = fs::write(&self.file, s);
    }

    fn restore(&mut self) {
        for (p, v) in self.items.iter().rev() {
            wr(p, v);
        }
        self.items.clear();
        let _ = fs::remove_file(&self.file);
    }

    /// Dipanggil saat daemon start: kembalikan nilai dari sesi sebelumnya yang crash.
    fn recover(name: &str) {
        let f = format!("{}/{}", CFG_DIR, name);
        if let Ok(t) = fs::read_to_string(&f) {
            for l in t.lines().rev() {
                let mut it = l.splitn(2, '\t');
                if let (Some(p), Some(v)) = (it.next(), it.next()) {
                    wr(Path::new(p), v);
                }
            }
            let _ = fs::remove_file(&f);
        }
    }
}

// ---------------------------------------------------------------- hardware

#[derive(PartialEq, Clone, Copy)]
enum Kind {
    Little,
    Mid,
    Prime,
}

struct Pol {
    dir: PathBuf,
    max: u64,
    kind: Kind,
}

struct Gpu {
    dir: PathBuf,
    max: u64,
    freqs: Vec<u64>,
    clock_mhz: Option<PathBuf>, // /sys/class/kgsl/kgsl-3d0/min_clock_mhz
    boost: Option<PathBuf>,     // devfreq/adrenoboost (jika ada)
    busy: Option<PathBuf>,      // kgsl-3d0/gpu_busy_percentage
}

impl Gpu {
    /// Set batas bawah GPU lewat devfreq + min_clock_mhz, lalu verifikasi (dilog beberapa kali pertama).
    fn set_min(&self, hz: u64) {
        use std::sync::atomic::{AtomicU32, Ordering};
        static N: AtomicU32 = AtomicU32::new(0);
        let hz = hz.min(self.max);
        let f = self.dir.join("min_freq");
        let ok = wr(&f, &hz.to_string());
        if let Some(c) = &self.clock_mhz {
            wr(c, &(hz / 1_000_000).to_string());
        }
        if N.fetch_add(1, Ordering::Relaxed) < 6 {
            let now = rd_u64(&f).unwrap_or(0);
            log(&format!("gpu set_min want={} write_ok={} readback={}", hz, ok, now));
        }
    }

    /// frekuensi terendah yang >= pct% dari max
    fn step(&self, pct: u64) -> u64 {
        let t = self.max * pct / 100;
        let mut best = self.max;
        for &f in &self.freqs {
            if f >= t && f < best {
                best = f;
            }
        }
        best
    }
}

struct Hw {
    uclamp: Option<PathBuf>,
    latency: Option<PathBuf>,
    pols: Vec<Pol>,
    gpu: Option<Gpu>,
    ncpu: usize,
    big_mask: u64,
}

fn parse_cpus(s: &str) -> u64 {
    let mut m = 0u64;
    for part in s.split_whitespace() {
        if let Ok(c) = part.parse::<u32>() {
            if c < 64 {
                m |= 1u64 << c;
            }
        }
    }
    m
}

fn discover() -> Hw {
    let mut uclamp = None;
    let mut latency = None;
    for base in ["/dev/cpuctl/top-app", "/sys/fs/cgroup/top-app", "/dev/cpuctl/foreground"] {
        let u = Path::new(base).join("cpu.uclamp.min");
        if u.exists() {
            let l = Path::new(base).join("cpu.uclamp.latency_sensitive");
            if l.exists() {
                latency = Some(l);
            }
            uclamp = Some(u);
            break;
        }
    }

    let mut raw: Vec<(PathBuf, u64, u64)> = Vec::new();
    if let Ok(rdir) = fs::read_dir("/sys/devices/system/cpu/cpufreq") {
        for e in rdir.flatten() {
            let name = e.file_name().to_string_lossy().to_string();
            if !name.starts_with("policy") {
                continue;
            }
            let dir = e.path();
            if let Some(max) = rd_u64(&dir.join("cpuinfo_max_freq")) {
                let mask = rd(&dir.join("related_cpus")).map(|s| parse_cpus(&s)).unwrap_or(0);
                raw.push((dir, max, mask));
            }
        }
    }
    let lmax = raw.iter().map(|r| r.1).min().unwrap_or(0);
    let gmax = raw.iter().map(|r| r.1).max().unwrap_or(0);
    let mut pols = Vec::new();
    let mut big_mask = 0u64;
    let mut all_mask = 0u64;
    for (dir, max, mask) in raw {
        all_mask |= mask;
        let kind = if lmax != gmax && max == lmax {
            Kind::Little
        } else if max == gmax {
            Kind::Prime
        } else {
            Kind::Mid
        };
        if kind != Kind::Little {
            big_mask |= mask;
        }
        pols.push(Pol { dir, max, kind });
    }
    if big_mask == 0 {
        big_mask = all_mask;
    }

    let mut ncpu = 0usize;
    if let Ok(rdir) = fs::read_dir("/sys/devices/system/cpu") {
        for e in rdir.flatten() {
            let n = e.file_name().to_string_lossy().to_string();
            if n.starts_with("cpu") && n[3..].chars().all(|c| c.is_ascii_digit()) && n.len() > 3 {
                ncpu += 1;
            }
        }
    }
    if ncpu == 0 || ncpu > 64 {
        ncpu = 8;
    }

    let gdir = PathBuf::from("/sys/class/kgsl/kgsl-3d0/devfreq");
    let gpu = if gdir.exists() {
        rd_u64(&gdir.join("max_freq")).map(|max| {
            let freqs = rd(&gdir.join("available_frequencies"))
                .map(|s| s.split_whitespace().filter_map(|x| x.parse::<u64>().ok()).collect::<Vec<u64>>())
                .unwrap_or_default();
            let cm = PathBuf::from("/sys/class/kgsl/kgsl-3d0/min_clock_mhz");
            let ab = gdir.join("adrenoboost");
            log(&format!(
                "gpu: max={} min={} steps={:?} min_clock_mhz={} adrenoboost={}",
                max,
                rd(&gdir.join("min_freq")).unwrap_or_default(),
                freqs,
                cm.exists(),
                ab.exists()
            ));
            Gpu {
                dir: gdir.clone(),
                max,
                freqs,
                clock_mhz: if cm.exists() { Some(cm) } else { None },
                boost: if ab.exists() { Some(ab) } else { None },
                busy: {
                    let b = PathBuf::from("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage");
                    if b.exists() { Some(b) } else { None }
                },
            }
        })
    } else {
        None
    };

    log(&format!(
        "hw: uclamp={} gpu={} policies={} ncpu={} big_mask={:x}",
        uclamp.is_some(),
        gpu.is_some(),
        pols.len(),
        ncpu,
        big_mask
    ));
    Hw { uclamp, latency, pols, gpu, ncpu, big_mask }
}

// ---------------------------------------------------------------- threads

fn critical_thread(tid: i32, pid: i32, comm: &str) -> bool {
    tid == pid
        || comm == "RenderThread"
        || comm == "UnityMain"
        || comm == "GameThread"
        || comm == "RHIThread"
        || comm.starts_with("UnityGfx")
        || comm.starts_with("UnrealRHI")
        || comm.starts_with("mali-")
}

fn list_threads(pid: i32) -> Vec<i32> {
    let mut v = Vec::new();
    if let Ok(rdir) = fs::read_dir(format!("/proc/{}/task", pid)) {
        for e in rdir.flatten() {
            if let Ok(tid) = e.file_name().to_string_lossy().parse::<i32>() {
                let comm = rd(&e.path().join("comm")).unwrap_or_default();
                if critical_thread(tid, pid, &comm) {
                    v.push(tid);
                }
            }
        }
    }
    v
}

fn list_sf_threads(pid: i32) -> Vec<i32> {
    let mut v = Vec::new();
    if let Ok(rdir) = fs::read_dir(format!("/proc/{}/task", pid)) {
        for e in rdir.flatten() {
            if let Ok(tid) = e.file_name().to_string_lossy().parse::<i32>() {
                let comm = rd(&e.path().join("comm")).unwrap_or_default();
                if tid == pid || comm.starts_with("RenderEngine") {
                    v.push(tid);
                }
            }
        }
    }
    v
}

fn find_sysui() -> Option<i32> {
    for e in fs::read_dir("/proc").ok()?.flatten() {
        if let Ok(pid) = e.file_name().to_string_lossy().parse::<i32>() {
            if pkg_of(pid).as_deref() == Some("com.android.systemui") {
                return Some(pid);
            }
        }
    }
    None
}

fn find_sf() -> Option<i32> {
    for e in fs::read_dir("/proc").ok()?.flatten() {
        if let Ok(pid) = e.file_name().to_string_lossy().parse::<i32>() {
            if pkg_of(pid).as_deref() == Some("/system/bin/surfaceflinger") {
                return Some(pid);
            }
        }
    }
    None
}

/// Aplikasi user (uid >= 10000) yang sedang foreground.
fn find_fg_app() -> Option<(String, i32)> {
    for e in fs::read_dir("/proc").ok()?.flatten() {
        if let Ok(pid) = e.file_name().to_string_lossy().parse::<i32>() {
            let uid = match fs::metadata(format!("/proc/{}", pid)) {
                Ok(m) => m.uid(),
                Err(_) => continue,
            };
            if uid < 10000 {
                continue;
            }
            if let Some(name) = pkg_of(pid) {
                if name.contains('.') && !name.contains(':') && is_foreground(pid) {
                    return Some((name, pid));
                }
            }
        }
    }
    None
}

/// Pembaca event input (sentuhan) non-blocking: true jika ada event baru.
struct Touch {
    files: Vec<fs::File>,
}

impl Touch {
    fn open() -> Touch {
        let mut files = Vec::new();
        if let Ok(rdir) = fs::read_dir("/dev/input") {
            for e in rdir.flatten() {
                let n = e.file_name().to_string_lossy().to_string();
                if n.starts_with("event") {
                    if let Ok(f) = fs::OpenOptions::new().read(true).custom_flags(0o4000).open(e.path()) {
                        files.push(f);
                    }
                }
            }
        }
        log(&format!("input devices: {}", files.len()));
        Touch { files }
    }

    fn drain(&mut self) -> bool {
        let mut any = false;
        let mut buf = [0u8; 4096];
        for f in self.files.iter_mut() {
            loop {
                match f.read(&mut buf) {
                    Ok(n) if n > 0 => any = true,
                    _ => break,
                }
            }
        }
        any
    }
}

fn set_affinity(tid: i32, mask: u64) {
    unsafe {
        sched_setaffinity(tid, 8, &mask as *const u64);
    }
}

fn set_nice(tid: i32, nice: i32) {
    unsafe {
        setpriority(0, tid as u32, nice);
    }
}

/// (waktu jalan ns, waktu menunggu runqueue ns)
fn schedstat(tid: i32, pid: i32) -> Option<(u64, u64)> {
    let t = fs::read_to_string(format!("/proc/{}/task/{}/schedstat", pid, tid)).ok()?;
    let mut it = t.split_whitespace();
    let run = it.next()?.parse().ok()?;
    let delay = it.next()?.parse().ok()?;
    Some((run, delay))
}

fn gpu_busy_pct(g: &Gpu) -> Option<u32> {
    let p = g.busy.as_ref()?;
    let t = fs::read_to_string(p).ok()?;
    let digits: String = t.trim().chars().take_while(|c| c.is_ascii_digit()).collect();
    digits.parse().ok()
}

fn spawn_cmd(args: Vec<String>) {
    std::thread::spawn(move || {
        let _ = Command::new("cmd").args(&args).output();
    });
}

// ---------------------------------------------------------------- session

#[derive(PartialEq, Clone, Copy)]
enum Mode {
    Game,
    Ui,
}

struct Session {
    pkg: String,
    pid: i32,
    sf: Option<i32>,
    sui: Option<i32>,
    lvl: usize,
    mode: Mode,
    saver: Saver,
    watch: Vec<(i32, i32)>, // (pid, tid)
    last: HashMap<(i32, i32), (u64, u64)>,
    last_wall: Option<Instant>,
    last_scan: Instant,
    prev_load: f64,
    peak: f64,
    gpu_b: i32,
    gb_low: Option<Instant>,
    last_gpu: Instant,
    bucket: i32,
    low_since: Option<Instant>,
    was_hot: bool,
}

impl Session {
    fn build_watch(pid: i32, sf: Option<i32>, sui: Option<i32>, mode: Mode) -> Vec<(i32, i32)> {
        let mut w: Vec<(i32, i32)> = list_threads(pid).into_iter().map(|t| (pid, t)).collect();
        if mode == Mode::Ui {
            if let Some(sp) = sf {
                for t in list_sf_threads(sp) {
                    w.push((sp, t));
                }
            }
            if let Some(up) = sui {
                if up != pid {
                    for t in list_threads(up) {
                        w.push((up, t));
                    }
                }
            }
        }
        w
    }

    fn base(pkg: &str, pid: i32, sf: Option<i32>, sui: Option<i32>, lvl: usize, mode: Mode, saver: Saver, watch: Vec<(i32, i32)>) -> Session {
        Session {
            pkg: pkg.to_string(),
            pid,
            sf,
            sui,
            lvl,
            mode,
            saver,
            watch,
            last: HashMap::new(),
            last_wall: None,
            last_scan: Instant::now(),
            prev_load: 0.0,
            peak: 0.0,
            gpu_b: 0,
            gb_low: None,
            last_gpu: Instant::now(),
            bucket: -1,
            low_since: None,
            was_hot: false,
        }
    }

    fn start(hw: &Hw, cfg: &Cfg, pkg: &str, pid: i32) -> Session {
        let lvl = cfg.level;
        let mut saver = Saver::new("state_game");
        if let Some(u) = &hw.uclamp {
            saver.remember(u);
        }
        if let Some(l) = &hw.latency {
            saver.remember(l);
            wr(l, "1");
        }
        for p in &hw.pols {
            let f = p.dir.join("scaling_min_freq");
            saver.remember(&f);
            let pct = match p.kind {
                Kind::Little => 0,
                Kind::Mid => MID[lvl],
                Kind::Prime => PRIME[lvl],
            };
            if pct > 0 {
                wr(&f, &(p.max * pct / 100).to_string());
            }
        }
        if let Some(g) = &hw.gpu {
            saver.remember(&g.dir.join("min_freq"));
            if let Some(c) = &g.clock_mhz {
                saver.remember(c);
            }
            if let Some(b) = &g.boost {
                saver.remember(b);
                wr(b, &(lvl + 1).to_string());
            }
        }

        let watch = Session::build_watch(pid, None, None, Mode::Game);
        for &(_, t) in &watch {
            set_affinity(t, hw.big_mask);
            set_nice(t, -6);
        }

        spawn_cmd(vec!["game".into(), "mode".into(), "performance".into(), pkg.to_string()]);
        log(&format!("GAME START {} pid={} level={} threads={}", pkg, pid, lvl, watch.len()));

        let mut s = Session::base(pkg, pid, None, None, lvl, Mode::Game, saver, watch);
        s.apply_bucket(hw, 0);
        s
    }

    /// Mode UI: ringan, tanpa pin/renice/freq floor, hanya uclamp + GPU bertahap, digerakkan sentuhan.
    fn start_ui(hw: &Hw, cfg: &Cfg, pkg: &str, pid: i32, sf: Option<i32>, sui: Option<i32>) -> Session {
        let mut saver = Saver::new("state_ui_app");
        if let Some(u) = &hw.uclamp {
            saver.remember(u);
        }
        for p in &hw.pols {
            saver.remember(&p.dir.join("scaling_min_freq"));
        }
        if let Some(g) = &hw.gpu {
            saver.remember(&g.dir.join("min_freq"));
            if let Some(c) = &g.clock_mhz {
                saver.remember(c);
            }
            if let Some(b) = &g.boost {
                saver.remember(b);
            }
        }
        let watch = Session::build_watch(pid, sf, sui, Mode::Ui);
        log(&format!("UI START {} pid={} threads={}", pkg, pid, watch.len()));
        let mut s = Session::base(pkg, pid, sf, sui, cfg.level, Mode::Ui, saver, watch);
        s.apply_bucket(hw, 0);
        s
    }

    fn apply_bucket(&mut self, hw: &Hw, b: i32) {
        let bi = b.clamp(0, 3) as usize;
        match self.mode {
            Mode::Game => {
                if let Some(u) = &hw.uclamp {
                    let v = (UCL[self.lvl] + UCL_ADD[bi]).min(95);
                    wr(u, &v.to_string());
                }
                for p in &hw.pols {
                    let f = p.dir.join("scaling_min_freq");
                    let (base, dynp) = match p.kind {
                        Kind::Little => (0u64, 0u64),
                        Kind::Mid => (MID[self.lvl], MID_G[bi]),
                        Kind::Prime => (PRIME[self.lvl], PRIME_G[bi]),
                    };
                    let pct = base.max(dynp);
                    if pct > 0 {
                        wr(&f, &(p.max * pct / 100).to_string());
                    } else if let Some(orig) = self.saver.get(&f) {
                        wr(&f, &orig);
                    }
                }
                if let Some(g) = &hw.gpu {
                    let gi = (self.gpu_b.max(b)).clamp(0, 3) as usize;
                    let pct = GPU_BASE[self.lvl].max(GPU_B[gi]);
                    g.set_min(g.step(pct));
                }
            }
            Mode::Ui => {
                // floor frekuensi CPU berlaku global (SystemUI/SurfaceFlinger tidak ada di cgroup top-app)
                for p in &hw.pols {
                    let f = p.dir.join("scaling_min_freq");
                    let pct = match p.kind {
                        Kind::Little => 0u64,
                        Kind::Mid => MID_UI[bi],
                        Kind::Prime => PRIME_UI[bi],
                    };
                    let pct = ((pct as f64) * UI_SCALE[self.lvl]).min(100.0) as u64;
                    if pct == 0 {
                        if let Some(orig) = self.saver.get(&f) {
                            wr(&f, &orig);
                        }
                    } else {
                        wr(&f, &(p.max * pct / 100).to_string());
                    }
                }
                if let Some(u) = &hw.uclamp {
                    let add = (UI_ADD[bi] as f64 * UI_SCALE[self.lvl]) as u32;
                    wr(u, &(UI_BASE + add).min(70).to_string());
                }
                if let Some(g) = &hw.gpu {
                    let gp = g.dir.join("min_freq");
                    if GPU_UI[bi] == 0 {
                        if let Some(orig) = self.saver.get(&gp) {
                            wr(&gp, &orig);
                        }
                        if let Some(c) = &g.clock_mhz {
                            if let Some(orig) = self.saver.get(c) {
                                wr(c, &orig);
                            }
                        }
                    } else {
                        g.set_min(g.step(GPU_UI[bi]));
                    }
                    if let Some(b) = &g.boost {
                        if bi >= 2 {
                            wr(b, "1");
                        } else if let Some(orig) = self.saver.get(b) {
                            wr(b, &orig);
                        }
                    }
                }
            }
        }
        self.bucket = b;
    }

    /// Dipanggil saat sentuhan baru dimulai setelah idle (mode UI).
    fn wake(&mut self, hw: &Hw) {
        self.last_wall = None;
        self.prev_load = 0.0;
        self.low_since = None;
        if self.bucket < 2 {
            self.apply_bucket(hw, 2); // touch boost: shade/animasi langsung dapat headroom
        }
    }

    /// Satu langkah prediktor.
    fn tick(&mut self, hw: &Hw) {
        let now = Instant::now();
        if now.duration_since(self.last_scan) > Duration::from_secs(2) {
            let fresh = Session::build_watch(self.pid, self.sf, self.sui, self.mode);
            if self.mode == Mode::Game {
                for &(p, t) in &fresh {
                    if !self.watch.contains(&(p, t)) {
                        set_affinity(t, hw.big_mask);
                        set_nice(t, -6);
                    }
                }
            }
            self.watch = fresh;
            self.last_scan = now;
        }

        let mut load = 0.0f64;
        let mut dly = 0.0f64;
        match self.last_wall {
            Some(lw) => {
                let wall = now.duration_since(lw).as_nanos() as f64;
                for &(p, t) in &self.watch {
                    if let Some((run, d)) = schedstat(t, p) {
                        if let Some((pr, pd)) = self.last.insert((p, t), (run, d)) {
                            if wall > 0.0 {
                                if run >= pr {
                                    load = load.max((run - pr) as f64 / wall);
                                }
                                if d >= pd {
                                    dly = dly.max((d - pd) as f64 / wall);
                                }
                            }
                        }
                    }
                }
            }
            None => {
                for &(p, t) in &self.watch {
                    if let Some(v) = schedstat(t, p) {
                        self.last.insert((p, t), v);
                    }
                }
            }
        }
        self.last_wall = Some(now);

        // prediksi: beban + ekstrapolasi kenaikan (attack cepat)
        let rise = (load - self.prev_load).max(0.0);
        let pred = (load + 2.0 * rise).min(1.0);
        self.prev_load = load;
        // peak-hold (half-life ~0.5 s): lantai agar tidak turun di antara frame berat
        self.peak = (self.peak * 0.995).max(load);

        let thr: [f64; 3] = if self.mode == Mode::Game { [0.30, 0.50, 0.70] } else { [0.40, 0.65, 0.85] };
        let bucket_of = |x: f64| -> i32 {
            if x > thr[2] {
                3
            } else if x > thr[1] {
                2
            } else if x > thr[0] {
                1
            } else {
                0
            }
        };
        let mut b = bucket_of(pred);
        if self.mode == Mode::Game {
            b = b.max(bucket_of(self.peak * 0.7));
        }
        // sinyal starvation: thread banyak menunggu runqueue -> core terlalu lambat/penuh
        if dly > 0.30 {
            b = b.max(3);
        } else if dly > 0.12 {
            b = b.max(2);
        }

        // sinyal GPU (tiap ~16 ms): hanya mempengaruhi frekuensi GPU
        if self.mode == Mode::Game && now.duration_since(self.last_gpu) >= Duration::from_millis(16) {
            self.last_gpu = now;
            if let Some(g) = &hw.gpu {
                if let Some(pct) = gpu_busy_pct(g) {
                    let gb = if pct > 85 {
                        3
                    } else if pct > 65 {
                        2
                    } else if pct > 45 {
                        1
                    } else {
                        0
                    };
                    if gb >= self.gpu_b {
                        self.gb_low = None;
                        if gb != self.gpu_b {
                            self.gpu_b = gb;
                            let cur = self.bucket.max(0);
                            self.apply_bucket(hw, cur);
                        }
                    } else {
                        let since = *self.gb_low.get_or_insert(now);
                        if now.duration_since(since) > Duration::from_millis(400) {
                            self.gb_low = None;
                            self.gpu_b = gb;
                            let cur = self.bucket.max(0);
                            self.apply_bucket(hw, cur);
                        }
                    }
                }
            }
        }

        if b >= self.bucket {
            self.low_since = None;
            if b != self.bucket {
                self.apply_bucket(hw, b);
            }
        } else {
            // turun harus stabil 300 ms
            let since = *self.low_since.get_or_insert(now);
            if now.duration_since(since) > Duration::from_millis(300) {
                self.low_since = None;
                self.apply_bucket(hw, b);
            }
        }
    }

    fn stop(mut self, hw: &Hw) {
        self.saver.restore();
        if self.mode == Mode::Game {
            let all: u64 = if hw.ncpu >= 64 { u64::MAX } else { (1u64 << hw.ncpu) - 1 };
            for &(_, t) in &self.watch {
                set_affinity(t, all);
                set_nice(t, 0);
            }
            spawn_cmd(vec!["game".into(), "reset".into(), self.pkg.clone()]);
            log(&format!("GAME STOP {}", self.pkg));
        } else {
            log(&format!("UI STOP {}", self.pkg));
        }
    }
}

// ---------------------------------------------------------------- foreground

fn pkg_of(pid: i32) -> Option<String> {
    let b = fs::read(format!("/proc/{}/cmdline", pid)).ok()?;
    let end = b.iter().position(|&c| c == 0).unwrap_or(b.len());
    Some(String::from_utf8_lossy(&b[..end]).to_string())
}

fn is_foreground(pid: i32) -> bool {
    rd(Path::new(&format!("/proc/{}/oom_score_adj", pid))).as_deref() == Some("0")
}

fn find_fg(cfg: &Cfg) -> Option<(String, i32)> {
    if cfg.games.is_empty() {
        return None;
    }
    for e in fs::read_dir("/proc").ok()?.flatten() {
        if let Ok(pid) = e.file_name().to_string_lossy().parse::<i32>() {
            if let Some(name) = pkg_of(pid) {
                if cfg.games.contains(&name) && is_foreground(pid) {
                    return Some((name, pid));
                }
            }
        }
    }
    None
}

// ---------------------------------------------------------------- main

fn main() {
    let _ = fs::create_dir_all(CFG_DIR);
    Saver::recover("state_game");
    Saver::recover("state_ui_app");
    Saver::recover("state_ui");
    let hw = discover();

    let mut sess: Option<Session> = None;
    let mut ui_saver = Saver::new("state_ui");
    let mut ui_on = false;
    let mut cfg = load_cfg();
    let mut touch = Touch::open();
    let mut sf_pid: Option<i32> = None;
    let mut sui_pid: Option<i32> = None;
    let mut last_touch = Instant::now() - Duration::from_secs(10);
    let mut last_check = Instant::now();
    let mut last_game_scan = Instant::now();

    log("daemon siap");
    loop {
        let mut new_sess: Option<Session> = None;
        let mut stop_now = false;

        match sess.as_mut() {
            None => {
                cfg = load_cfg();

                // baseline UI smooth
                if let Some(u) = &hw.uclamp {
                    if cfg.ui && !ui_on {
                        ui_saver.remember(u);
                        wr(u, &UI_BASE.to_string());
                        ui_on = true;
                    } else if !cfg.ui && ui_on {
                        ui_saver.restore();
                        ui_on = false;
                    }
                }

                if let Some((pkg, pid)) = find_fg(&cfg) {
                    new_sess = Some(Session::start(&hw, &cfg, &pkg, pid));
                } else if cfg.ui {
                    if let Some((pkg, pid)) = find_fg_app() {
                        if sf_pid.map(|p| pkg_of(p).is_none()).unwrap_or(true) {
                            sf_pid = find_sf();
                        }
                        if sui_pid.map(|p| pkg_of(p).is_none()).unwrap_or(true) {
                            sui_pid = find_sysui();
                        }
                        new_sess = Some(Session::start_ui(&hw, &cfg, &pkg, pid, sf_pid, sui_pid));
                    }
                }
                if new_sess.is_some() {
                    last_check = Instant::now();
                    last_game_scan = Instant::now();
                } else {
                    sleep(Duration::from_millis(if cfg.ui { 400 } else { 1000 }));
                }
            }
            Some(s) => {
                if s.mode == Mode::Game {
                    s.tick(&hw);
                    if last_check.elapsed() > Duration::from_secs(1) {
                        last_check = Instant::now();
                        let alive = pkg_of(s.pid).as_deref() == Some(s.pkg.as_str());
                        if !alive || !is_foreground(s.pid) {
                            stop_now = true;
                        }
                    }
                    if !stop_now {
                        sleep(Duration::from_millis(TICK_MS));
                    }
                } else {
                    // mode UI: aktif hanya saat ada sentuhan (atau masih ramp-down)
                    if touch.drain() {
                        last_touch = Instant::now();
                    }
                    let hot = last_touch.elapsed() < Duration::from_millis(1500) || s.bucket > 0;
                    if hot {
                        if !s.was_hot {
                            s.wake(&hw);
                        }
                        s.was_hot = true;
                        s.tick(&hw);
                    } else {
                        s.was_hot = false;
                    }

                    if last_check.elapsed() > Duration::from_millis(300) {
                        last_check = Instant::now();
                        let alive = pkg_of(s.pid).as_deref() == Some(s.pkg.as_str());
                        if !alive || !is_foreground(s.pid) {
                            stop_now = true;
                        }
                    }
                    if !stop_now && last_game_scan.elapsed() > Duration::from_secs(1) {
                        last_game_scan = Instant::now();
                        cfg = load_cfg();
                        if !cfg.ui || find_fg(&cfg).is_some() {
                            stop_now = true;
                        }
                    }
                    if !stop_now {
                        sleep(Duration::from_millis(if hot { 16 } else { 50 }));
                    }
                }
            }
        }

        if new_sess.is_some() {
            sess = new_sess;
        }
        if stop_now {
            if let Some(done) = sess.take() {
                done.stop(&hw);
            }
            if ui_on {
                if let Some(u) = &hw.uclamp {
                    wr(u, &UI_BASE.to_string());
                }
            }
        }
        let _ = std::io::stderr().flush();
    }
}
