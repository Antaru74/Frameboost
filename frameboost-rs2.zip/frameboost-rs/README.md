# FrameBoost Native (Rust)

Daemon root `fbd` + modul KernelSU/Magisk. Tanpa LSPosed, tanpa app.

- Deteksi game foreground dari /proc (cmdline + oom_score_adj == 0).
- Sampling schedstat thread kritis (main, RenderThread, UnityMain, GameThread, RHI) tiap 8 ms.
- Prediksi beban = beban + 1.5 x kenaikan -> bucket 0-3 -> uclamp.min top-app + min freq GPU bertingkat.
- Saat game mulai: naikkan min freq cluster tengah/prime, pin thread kritis ke core tengah+prime, renice, `cmd game mode performance`.
- Saat game berhenti: semua nilai dikembalikan (tahan crash lewat file state).
- Mode UI (ui_smooth=1): untuk aplikasi foreground apa pun, prediktor ringan digerakkan sentuhan (/dev/input), memantau thread app + SurfaceFlinger, uclamp dan GPU naik bertahap lalu kembali saat idle.

Konfigurasi: /data/adb/frameboost/games.txt dan config.txt (daemon membaca ulang tiap detik saat idle).
Log: /data/adb/frameboost/fbd.log
