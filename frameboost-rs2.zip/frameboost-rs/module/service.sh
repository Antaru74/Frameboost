#!/system/bin/sh
MODDIR=${0%/*}
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 5
pkill -f "$MODDIR/bin/fbd" 2>/dev/null
nohup "$MODDIR/bin/fbd" >> /data/adb/frameboost/fbd.log 2>&1 &
