SKIPUNZIP=0
[ "$ARCH" = "arm64" ] || abort "! Hanya arm64 yang didukung"
mkdir -p /data/adb/frameboost
[ -f /data/adb/frameboost/games.txt ]  || cp "$MODPATH/config/games.txt"  /data/adb/frameboost/games.txt
[ -f /data/adb/frameboost/config.txt ] || cp "$MODPATH/config/config.txt" /data/adb/frameboost/config.txt
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/bin/fbd" 0 0 0755
ui_print "- Edit daftar game: /data/adb/frameboost/games.txt"
ui_print "- Level & UI smooth: /data/adb/frameboost/config.txt"
