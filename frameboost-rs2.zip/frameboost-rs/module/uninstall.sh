#!/system/bin/sh
pkill -f frameboost/bin/fbd 2>/dev/null
rm -rf /data/adb/frameboost
